/**
 * AdBlock detector script
 */
( function() {
	'use strict';
	var node = document.createElement( 'div' );
	node.id = 'hustle_optin_adBlock_detector';
	node.style.display = 'none';
	document.body.appendChild( node );
}() );
