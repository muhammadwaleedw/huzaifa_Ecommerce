<?php
/**
 * To remove in 4.4.0. Left in the meantime to prevent errors.
 */
class Hustle_Popup_Emails extends Hustle_Meta {

}
