<?php
/**
 * Remove this class in 4.4.0. Left here in the meantime to prevent errors.
 */
class Hustle_Popup_Content extends Hustle_Meta {

}
