<?php

/**
 * Remove in 4.4.0. Left in the meantime to prevent errors.
 */
class Hustle_Embedded_Settings extends Hustle_Meta_Base_Settings {

}
