<?php

/**
 * Remove in 4.4.0. Left here in the meantime to prevent errors.
 */
class Hustle_Embedded_Display extends Hustle_Meta {

}
