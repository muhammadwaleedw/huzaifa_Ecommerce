<?php

// TODO: remove in 4.4.0. Left in the meantime to prevent errors.
class Hustle_Collection {

}
