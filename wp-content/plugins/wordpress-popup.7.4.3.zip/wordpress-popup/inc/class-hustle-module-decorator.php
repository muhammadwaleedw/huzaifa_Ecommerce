<?php

/**
 * Class Hustle_Module_Decorator
 * To be removed. Deprecated in 4.3.0
 */
class Hustle_Module_Decorator {

}
